<!DOCTYPE html>
<html lang="en">
<head>
    <title>Asamblea Coopserp - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .option-container {
            margin-top: 10px;
            border: 1px solid #ddd;
            padding: 5px;
            border-radius: 5px;
        }
        .option-container input {
            width: 95%;
            margin: 5px;
        }
        .question-label {
            color: black;
            font-weight: bold;
            font-size: 15px;
        }

        .alert {
        font-size: 30px; /* Cambia esto según tus necesidades */
        }
    </style>
<style>
    .form-container {
        background-color: #f5f5f5;
        padding: 20px;
        border-radius: 10px;
    }

    .custom-form h2, .custom-form h3 {
        color: #333;
        margin-bottom: 15px;
    }

    .form-option {
        margin-bottom: 10px;
    }

    .btn-submit {
        background-color: #007bff;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .next-question {
        display: block;
        margin-top: 20px;
        font-size: 18px;
    }
</style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
</head>
<body>
    <div class="wrapper d-flex align-items-stretch">
        
        <?php $__env->startSection('content'); ?>
        <div id="content" class="p-4 p-md-5">
            <button type="button" id="sidebarCollapse" class="btn btn-primary mb-3">
                <i class="fa fa-bars"></i>
            </button>
            <br>
            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->rol == 'admin'): ?>
                
                <?php if(session('error')): ?>
                <div class="alert alert-warning">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('success')): ?>
                <div class="alert alert-warning">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="container">
                <div class="container">
                    <br>

                <div class="container">
                    <div>
                        <?php if(!$hasVoted): ?>
                        <form action="<?php echo e(route('form.save-response', ['formId' => $currentForm->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label class="form-label" style="font-size: 50px; color: black; font-weight: bold; text-align: center"><?php echo e($currentForm->name); ?></label>
                                <br>
                                <label class="form-label" style="font-size: 35px; color: black;"> <?php echo e($field->label); ?></label>
                                <?php if($field->type === 'multiple' || $field->type === 'yes_no'): ?>
                                    <?php if(is_array($field->options)): ?>
                                        <?php $__currentLoopData = $field->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-check">
                                                <p type="radio" name="<?php echo e('field_' . $field->id); ?>" id="<?php echo e('field_' . $field->id . '_' . $loop->index); ?>" value="<?php echo e($option); ?>">
                                                <label style="font-size: 25px" for="<?php echo e('field_' . $field->id . '_' . $loop->index); ?>">
                                                    ➣  <?php echo e($option); ?>

                                                </label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <a  href="<?php echo e(route('form-field.toggle-active', $field->id)); ?>" class="btn btn-warning">
                                <?php echo e($field->is_active ? 'Desactivar' : 'Activar'); ?> Pregunta
                            </a>

                        </form>
                    <?php else: ?>
                        <div class="alert alert-info">Ya has votado en este campo.</div>
                    <?php endif; ?>
                        <br>
                    </div>
                    <a style="font-size:20px; margin-right:25px; display: inline-block; color: black" href="<?php echo e(route('form.show-field', ['formId' => $form->id, 'fieldIndex' => $fieldIndex - 1])); ?>"><i class="bi bi-arrow-left-short"></i>Pregunta Anterior </a>
                    <a style="font-size:20px; margin-right:25px; display: inline-block; color: black" href="<?php echo e(route('form.show-field', ['formId' => $form->id, 'fieldIndex' => $fieldIndex + 1])); ?>">Siguiente Pregunta <i class="bi bi-arrow-right-short"></i></a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php if(in_array(Auth::user()->rol, ['DELEGADO', 'SUPLENTE'])): ?>
            <?php if(session('error')): ?>
            <div class="alert alert-warning"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
            <div class="container">

                <div class="form-container">
                    <?php if(!$hasVoted): ?>
                        <form action="<?php echo e(route('form.save-response', ['formId' => $currentForm->id])); ?>" method="POST" class="custom-form">
                            <?php echo csrf_field(); ?>
                            <h2 style="font-size: 50px; color: black; font-weight: bold; text-align: center" class="form-title"><?php echo e($currentForm->name); ?></h2>
                            <h3 style="font-size: 35px" class="form-subtitle"><?php echo e($field->label); ?></h3>
            
                            <!-- Opciones del formulario -->
                            <?php if($field->type === 'multiple' || $field->type === 'yes_no'): ?>
                                <?php if(is_array($field->options)): ?>
                                    <?php $__currentLoopData = $field->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-option">
                                            <input type="radio" name="<?php echo e('field_' . $field->id); ?>" id="<?php echo e('field_' . $field->id . '_' . $loop->index); ?>" value="<?php echo e($option); ?>">
                                            <label style="font-size: 25px" for="<?php echo e('field_' . $field->id . '_' . $loop->index); ?>"><?php echo e($option); ?></label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endif; ?>
            
                            <button style="font-size: 20px" type="submit" class="btn btn-primary mb-3">Enviar Respuesta</button>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-info">Ya has votado en este campo.</div>
                        <div class="mb-3">
                            <h2 style="font-size: 50px; color: black; font-weight: bold; text-align: center" class="form-title"><?php echo e($currentForm->name); ?></h2>
                            <br>
                            <label class="form-label" style="font-size: 35px; color: black;"><?php echo e($field->label); ?></label>
                            <?php if($field->type === 'multiple' || $field->type === 'yes_no'): ?>
                                <?php if(is_array($field->options)): ?>
                                    <?php $__currentLoopData = $field->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check">
                                            <p style="color: black" type="radio" name="<?php echo e('field_' . $field->id); ?>" id="<?php echo e('field_' . $field->id . '_' . $loop->index); ?>" value="<?php echo e($option); ?>">
                                            <label style="font-size: 25px; color:black" for="<?php echo e('field_' . $field->id . '_' . $loop->index); ?>">
                                                ➣ <?php echo e($option); ?>

                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    </div>
                    <a style="font-size: 25px; ; color: black" href="<?php echo e(route('form.show-field', ['formId' => $form->id, 'fieldIndex' => $fieldIndex + 1])); ?>">Siguiente Pregunta <i class="bi bi-arrow-right-short"></i></a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        
        <?php $__env->stopSection(); ?>
    </div>
</body>
</html>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\JSANDOVA\Documents\GitHub\Nueva-carpeta\asamblea_app\resources\views/asamblea.blade.php ENDPATH**/ ?>