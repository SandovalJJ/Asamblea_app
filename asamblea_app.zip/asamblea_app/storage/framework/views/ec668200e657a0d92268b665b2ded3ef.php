<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Iniciar sesión - Asamblea</title>
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/styles.css">

       
    </head>
<div class="container-fluid ps-md-0">
  <div class="row g-0">
    <div class="d-none d-md-flex col-md-4 col-lg-6 bg-image"></div>
    <div class="col-md-8 col-lg-6">
      <div class="login d-flex align-items-center py-5">
        <div class="container">
          <div class="row">
            <div class="col-md-9 col-lg-8 mx-auto">
                <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>

              <h3 class="login-heading mb-4">¡Bienvenido al software de asamblea!</h3>
              <form action="<?php echo e(route('iniciar')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-floating mb-3">
                    <input name="loginname" type="email" id="examplename"  placeholder="Correo electrónico" class="form-control">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <label for="floatingInput">Correo electrónico</label>
                </div>
                <div class="form-floating mb-3"> 
                    <input name="loginpassword" type="password" placeholder="Contraseña" class="form-control">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <label for="floatingPassword">Contraseña</label>
                </div>
                <div class="d-grid">
                  <button type="submit" class="btn btn-outline-primary btn-lg" type="submit">Iniciar sesión</button>
                  <div class="text-center">
                  </div>
                </div>

                </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

    </body>
</html>


<?php /**PATH C:\Users\JSANDOVA\Documents\GitHub\Nueva-carpeta\asamblea_app\resources\views/login.blade.php ENDPATH**/ ?>