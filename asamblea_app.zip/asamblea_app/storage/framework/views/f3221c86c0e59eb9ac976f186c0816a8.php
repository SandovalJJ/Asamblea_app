<!doctype html>
<html lang="en">
<head>
    <title>Asamblea Coopserp - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    .option-container {
        margin-top: 10px;
        border: 1px solid #ddd;
        padding: 5px;
        border-radius: 5px;
    }
    .option-container input {
        width: 95%;
        margin: 5px;
    }
    .question-label {
        color: black;
        font-weight: bold;
        font-size: 15px;
    }
    .modal-body {
    max-height: 400px; /* Ajusta este valor según tus necesidades */
    overflow-y: auto; /* Permite desplazamiento vertical si el contenido es más largo */
}
#buscarUsuario {
    margin-bottom: 10px;
}

/* Estilos para el botón de seleccionar todo */
.btn-seleccionar-todo {
    margin-bottom: 10px;
}
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
</head>
<body>
   

    <div class="wrapper d-flex align-items-stretch">
        
        <?php $__env->startSection('content'); ?>
        <div id="content" class="p-4 p-md-5">
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->rol == 'admin'): ?>
            <button type="button" id="sidebarCollapse" class="btn btn-primary">
                <i class="fa fa-bars"></i>
              </button>
            <div class="container">
                <h1>Lista de Formularios</h1>
                <?php $__currentLoopData = $formularios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formulario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-3 shadow">
                        <div class="card-header">
                            <h2 data-bs-toggle="collapse" href="#collapse<?php echo e($formulario->id); ?>" role="button" aria-expanded="false" aria-controls="collapse<?php echo e($formulario->id); ?>">
                                <i style="" class="bi bi-caret-down"></i> <?php echo e($formulario->name); ?>

                            </h2>
                        </div>
                        <div id="collapse<?php echo e($formulario->id); ?>" class="collapse">
                            <div class="card-body">
                                <?php $__currentLoopData = $formulario->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="mb-3">
                                        <label class="form-label"><?php echo e($field->label); ?></label>
                                        <?php if($field->type === 'multiple' || $field->type === 'yes_no'): ?>
                                            <?php if(is_array($field->options)): ?>
                                                <?php $__currentLoopData = $field->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="form-check">
                                                        <input  type="radio" name="<?php echo e($field->label); ?>" id="<?php echo e($option); ?>">
                                                        <label for="<?php echo e($option); ?>">
                                                            <?php echo e($option); ?>

                                                        </label>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-between">
                            <a href="/respuestas-<?php echo e($formulario->id); ?>" class="btn btn-primary">Respuestas</a>
                        
                            <div>
                                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalUsuarios<?php echo e($formulario->id); ?>">
                                    Asignar Usuarios
                                </button>
                        
                                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalDesasignarUsuarios<?php echo e($formulario->id); ?>">
                                    Desasignar Usuarios
                                </button>
                            </div>
                        </div>
                        
                        <div class="modal fade" id="modalUsuarios<?php echo e($formulario->id); ?>" tabindex="-1" aria-labelledby="modalUsuariosLabel" aria-hidden="true">
                            <div class="modal-dialog ">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="modalUsuariosLabel">Asignar Usuarios a <?php echo e($formulario->name); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <form action="<?php echo e(route('assign-users', $formulario->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">
                                            <input type="text" class="form-control mb-3" id="buscarUsuario<?php echo e($formulario->id); ?>" placeholder="Buscar usuario...">
                                            <button type="button" class="btn btn-outline-primary btn-sm mb-3" onclick="seleccionarTodos(<?php echo e($formulario->id); ?>)">Seleccionar Todos</button>
                                            <?php $__currentLoopData = $usuariosParaAsignarPorFormulario[$formulario->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="user<?php echo e($usuario->id); ?>_<?php echo e($formulario->id); ?>" name="user_ids[]" value="<?php echo e($usuario->id); ?>">
                                                    <label class="form-check-label" for="user<?php echo e($usuario->id); ?>_<?php echo e($formulario->id); ?>"><?php echo e($usuario->name); ?></label>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="modal-footer">
                                            
                                            <button type="submit" class="btn btn-success">Asignar Usuarios</button>
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="modal" id="modalDesasignarUsuarios<?php echo e($formulario->id); ?>" tabindex="-1" aria-labelledby="modalDesasignarUsuariosLabel" aria-hidden="true">
                            <div class="modal-dialog ">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="modalUsuariosLabel">Desasignar Usuarios a <?php echo e($formulario->name); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <form action="<?php echo e(route('unassign-users', $formulario->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">
                                             <input type="text" class="form-control mb-3" onkeyup="filtrarUsuariosDesasignar(this.value, <?php echo e($formulario->id); ?>)" placeholder="Buscar usuario...">
                                             <button type="button" class="btn btn-outline-primary btn-sm mb-3" onclick="seleccionarTodosDesasignar(<?php echo e($formulario->id); ?>)">Seleccionar Todos</button>
                                             <?php $__currentLoopData = $usuariosAsignadosPorFormulario [$formulario->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input user-checkbox" id="user<?php echo e($usuario->id); ?>_<?php echo e($formulario->id); ?>" name="user_ids[]" value="<?php echo e($usuario->id); ?>">
                                                <label class="form-check-label" for="user<?php echo e($usuario->id); ?>_<?php echo e($formulario->id); ?>"><?php echo e($usuario->name); ?></label>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-danger">Desasignar Usuarios Seleccionados</button>
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
<?php endif; ?>
<?php endif; ?>

        
        <script>
            // Función para seleccionar/deseleccionar todos los checkboxes de usuarios
            function seleccionarTodosDesasignar(formularioId) {
                const checkboxes = document.querySelectorAll(`#modalDesasignarUsuarios${formularioId} .user-checkbox`);
                const todosSeleccionados = Array.from(checkboxes).every(checkbox => checkbox.checked);
                checkboxes.forEach(checkbox => checkbox.checked = !todosSeleccionados);
            }
            
            // Función para filtrar la lista de usuarios en el modal de desasignar
            function filtrarUsuariosDesasignar(filtro, formularioId) {
                const texto = filtro.toUpperCase();
                const labels = document.querySelectorAll(`#modalDesasignarUsuarios${formularioId} .form-check-label`);
            
                labels.forEach(label => {
                    const itemText = label.textContent || label.innerText;
                    const parentDiv = label.closest('.form-check');
                    if (itemText.toUpperCase().indexOf(texto) > -1) {
                        parentDiv.style.display = "";
                    } else {
                        parentDiv.style.display = "none";
                    }
                });
            }
            </script>
            
        <script>
            // Función para seleccionar o deseleccionar todos los usuarios
            function seleccionarTodos(formularioId) {
                let checkboxes = document.querySelectorAll('#modalUsuarios' + formularioId + ' .form-check-input');
                let todosSeleccionados = true;
                // Verifica si todos los checkboxes ya están seleccionados
                checkboxes.forEach(function(checkbox) {
                    if (!checkbox.checked) todosSeleccionados = false;
                });
                // Establece todos los checkboxes al valor contrario
                checkboxes.forEach(function(checkbox) {
                    checkbox.checked = !todosSeleccionados;
                });
            }
            
            // Función para filtrar la lista de usuarios basado en la búsqueda
            document.addEventListener("DOMContentLoaded", () => {
                document.querySelectorAll('[id^=buscarUsuario]').forEach(inputBusqueda => {
                    inputBusqueda.addEventListener("keyup", function() {
                        let formularioId = this.id.replace('buscarUsuario', '');
                        let filtro = this.value.toUpperCase();
                        let modalBody = document.querySelector('#modalUsuarios' + formularioId + ' .modal-body');
                        let labels = modalBody.querySelectorAll('.form-check-label');
                        labels.forEach(function(label) {
                            let txtValue = label.textContent || label.innerText;
                            if (txtValue.toUpperCase().indexOf(filtro) > -1) {
                                label.closest('.form-check').style.display = "";
                            } else {
                                label.closest('.form-check').style.display = "none";
                            }
                        });
                    });
                });
            });
            </script>
        <?php $__env->stopSection(); ?>
    </div>
</body>
</html>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\JSANDOVA\Documents\GitHub\Nueva-carpeta\asamblea_app\resources\views/show_formulario.blade.php ENDPATH**/ ?>